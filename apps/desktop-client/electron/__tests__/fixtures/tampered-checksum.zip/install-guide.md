# Offline Bundle 설치 안내

- 요청자: dev-user@miracom.com
- 대상 사업장: gumi
- 생성 시각: 2026-08-03T13:31:26.946432+00:00

## 설치 순서

1. knowledge

## 포함 자산

- [필수] 재택근무 정책 Knowledge (1.0.0) — APPROVED

## 설치 절차

1. Desktop Client에서 이 Bundle 파일을 선택해 반입(Import)합니다.
2. Checksum과 Manifest 검증이 자동으로 수행됩니다.
3. 위 설치 순서대로 Prompt, Knowledge, Agent, Service, Office Profile이 설치됩니다.
4. 필요한 Ollama 모델과 MCP 연결 상태를 확인하세요.
